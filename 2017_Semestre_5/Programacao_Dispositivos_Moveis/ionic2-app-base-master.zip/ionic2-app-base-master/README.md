Ionic App Base
=====================

This is the base template for Ionic starter apps.

## Using this project

Install the latest Ionic CLI:

```bash
$ npm install -g ionic
```

Then run:

```bash
$ ionic start myApp
```

More info on this can be found on the Ionic [Getting Started](http://ionicframework.com/docs/v2/getting-started/) page.
